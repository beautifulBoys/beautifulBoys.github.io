﻿window.onload = function() {
	//弹出显示信息
	$('.sao').xianshi('该功能正在完善过程');
	$('.ma').xianshi('该功能正在完善过程');	
}
